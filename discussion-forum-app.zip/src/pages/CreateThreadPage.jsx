export default function CreateThreadPage() {
  return (
    <>
      <h1>Add New Thread</h1>
      <form>
        <input type="text" />
      </form>
    </>
  );
}
